"""export.py - CSV export and database backup, plus the Data Management screen."""
import csv
import sqlite3
import tkinter as tk
from tkinter import filedialog, messagebox
from datetime import datetime
import database
from ui import *


def export_expenses_csv(path):
    rows = database.get_expenses()
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["ID", "Date", "Name", "Category", "Amount", "Payment", "Description"])
        for r in rows:
            w.writerow([r["id"], r["date"], r["name"], r["category"], r["amount"], r["payment"], r["description"]])
    return len(rows)


def export_income_csv(path):
    rows = database.get_income()
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["ID", "Date", "Source", "Amount", "Description"])
        for r in rows:
            w.writerow([r["id"], r["date"], r["source"], r["amount"], r["description"]])
    return len(rows)


class DataPage(Page):
    def __init__(self, parent, app):
        super().__init__(parent, app)
        heading(self, "Data Management")
        box = tk.Frame(self, bg=WHITE, padx=25, pady=20)
        box.pack(anchor="nw", padx=25, pady=10)
        tk.Label(box, text="All data is stored offline in a local SQLite database:\n" + database.DB_PATH,
                 bg=WHITE, font=FONT, justify="left", fg=TEXT).pack(anchor="w", pady=(0, 15))
        button(box, "Export Expenses to CSV", self.exp_csv).pack(anchor="w", pady=5)
        button(box, "Export Income to CSV", self.inc_csv).pack(anchor="w", pady=5)
        button(box, "Backup Database", self.backup, "success").pack(anchor="w", pady=5)

    def _ask(self, prefix, ext):
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        return filedialog.asksaveasfilename(defaultextension=ext, initialfile=f"{prefix}_{stamp}{ext}")

    def _do(self, prefix, ext, action, ok_msg):
        path = self._ask(prefix, ext)
        if not path:
            return
        try:
            result = action(path)
        except (OSError, sqlite3.Error) as err:
            return messagebox.showerror("Error", f"Could not complete the operation:\n{err}")
        messagebox.showinfo("Success", ok_msg.format(n=result, path=path))

    def exp_csv(self):
        self._do("expenses", ".csv", export_expenses_csv, "{n} expense records exported to:\n{path}")

    def inc_csv(self):
        self._do("income", ".csv", export_income_csv, "{n} income records exported to:\n{path}")

    def backup(self):
        self._do("expense_calculator_backup", ".db", database.backup_database, "Backup saved to:\n{path}")
