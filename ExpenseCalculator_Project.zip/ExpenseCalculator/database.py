"""database.py - All SQLite database operations for Expense Calculator."""
import os
import random
import shutil
import sqlite3
from datetime import date, timedelta

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_DIR = os.path.join(BASE_DIR, "database")
DB_PATH = os.path.join(DB_DIR, "expense_calculator.db")


def get_connection():
    """Open a connection to the SQLite database (creates folder if needed)."""
    os.makedirs(DB_DIR, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def run(sql, params=(), fetch=False):
    """Run one SQL statement. Returns rows if fetch=True, else last row id."""
    conn = get_connection()
    try:
        cur = conn.execute(sql, params)
        if fetch:
            return cur.fetchall()
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def init_db():
    """Create tables and insert demo data on the very first run."""
    run("""CREATE TABLE IF NOT EXISTS expenses (
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
        amount REAL NOT NULL, category TEXT NOT NULL, date TEXT NOT NULL,
        payment TEXT, description TEXT)""")
    run("""CREATE TABLE IF NOT EXISTS income (
        id INTEGER PRIMARY KEY AUTOINCREMENT, source TEXT NOT NULL,
        amount REAL NOT NULL, date TEXT NOT NULL, description TEXT)""")
    run("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT)")
    if get_setting("seeded") is None:
        seed_demo_data()
        set_setting("seeded", "yes")


# ---------------- settings ----------------
def get_setting(key, default=None):
    rows = run("SELECT value FROM settings WHERE key=?", (key,), fetch=True)
    return rows[0]["value"] if rows else default


def set_setting(key, value):
    run("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (key, str(value)))


# ---------------- expenses ----------------
def add_expense(name, amount, category, day, payment, description):
    return run("INSERT INTO expenses (name, amount, category, date, payment, description) "
               "VALUES (?,?,?,?,?,?)", (name, amount, category, day, payment, description))


def update_expense(exp_id, name, amount, category, day, payment, description):
    run("UPDATE expenses SET name=?, amount=?, category=?, date=?, payment=?, description=? "
        "WHERE id=?", (name, amount, category, day, payment, description, exp_id))


def delete_expense(exp_id):
    run("DELETE FROM expenses WHERE id=?", (exp_id,))


def get_expense(exp_id):
    rows = run("SELECT * FROM expenses WHERE id=?", (exp_id,), fetch=True)
    return rows[0] if rows else None


def get_expenses(search="", category="All", date_from="", date_to=""):
    """Return expenses matching the filters, newest first."""
    sql, params = "SELECT * FROM expenses WHERE 1=1", []
    if search:
        sql += " AND (name LIKE ? OR description LIKE ? OR category LIKE ?)"
        params += [f"%{search}%"] * 3
    if category and category != "All":
        sql += " AND category=?"
        params.append(category)
    if date_from:
        sql += " AND date>=?"
        params.append(date_from)
    if date_to:
        sql += " AND date<=?"
        params.append(date_to)
    return run(sql + " ORDER BY date DESC, id DESC", params, fetch=True)


# ---------------- income ----------------
def add_income(source, amount, day, description):
    return run("INSERT INTO income (source, amount, date, description) VALUES (?,?,?,?)",
               (source, amount, day, description))


def delete_income(inc_id):
    run("DELETE FROM income WHERE id=?", (inc_id,))


def get_income():
    return run("SELECT * FROM income ORDER BY date DESC, id DESC", fetch=True)


# ---------------- totals / summaries ----------------
def _sum(table, date_from=None, date_to=None, category=None):
    sql, params = f"SELECT SUM(amount) AS t FROM {table} WHERE 1=1", []
    if date_from:
        sql += " AND date>=?"
        params.append(date_from)
    if date_to:
        sql += " AND date<=?"
        params.append(date_to)
    if category:
        sql += " AND category=?"
        params.append(category)
    return run(sql, params, fetch=True)[0]["t"] or 0.0


def sum_expenses(date_from=None, date_to=None, category=None):
    return _sum("expenses", date_from, date_to, category)


def sum_income(date_from=None, date_to=None):
    return _sum("income", date_from, date_to)


def count_transactions():
    e = run("SELECT COUNT(*) c FROM expenses", fetch=True)[0]["c"]
    i = run("SELECT COUNT(*) c FROM income", fetch=True)[0]["c"]
    return e + i


def category_totals(date_from=None, date_to=None):
    sql, params = "SELECT category, SUM(amount) t FROM expenses WHERE 1=1", []
    if date_from:
        sql += " AND date>=?"
        params.append(date_from)
    if date_to:
        sql += " AND date<=?"
        params.append(date_to)
    rows = run(sql + " GROUP BY category ORDER BY t DESC", params, fetch=True)
    return [(r["category"], r["t"]) for r in rows]


def expense_by_day(date_from, date_to):
    rows = run("SELECT date, SUM(amount) t FROM expenses WHERE date>=? AND date<=? "
               "GROUP BY date ORDER BY date", (date_from, date_to), fetch=True)
    return {r["date"]: r["t"] for r in rows}


def last_months(n=6):
    """Return the last n months as 'YYYY-MM' strings (oldest first)."""
    today = date.today()
    y, m, out = today.year, today.month, []
    for _ in range(n):
        out.append(f"{y}-{m:02d}")
        m -= 1
        if m == 0:
            m, y = 12, y - 1
    return out[::-1]


def month_totals(table, months):
    """Total amount per month for 'expenses' or 'income' table."""
    if table not in ("expenses", "income"):
        raise ValueError("Invalid table")
    rows = run(f"SELECT substr(date,1,7) m, SUM(amount) t FROM {table} GROUP BY m", fetch=True)
    data = {r["m"]: r["t"] for r in rows}
    return [data.get(m, 0.0) for m in months]


# ---------------- demo data ----------------
def seed_demo_data():
    """Insert sample records so the app can be tested immediately."""
    rnd = random.Random(42)
    samples = {
        "Food": ["Mess bill", "Canteen lunch", "Snacks", "Tea & samosa", "Dinner"],
        "Travel": ["Bus pass", "Auto fare", "Train ticket", "Petrol"],
        "Shopping": ["T-shirt", "Shoes", "Groceries"],
        "Education": ["Notebooks", "Photocopy", "Exam fees", "Online course"],
        "Electricity": ["Electricity bill"],
        "Rent": ["Room rent", "Shop rent"],
        "Stock/Purchase": ["Rice & dal stock", "Oil & spices", "Packaged goods"],
        "Staff Salary": ["Helper salary"],
        "Supplier Payment": ["Wholesaler payment", "Dairy supplier"],
        "Business Expense": ["Packaging bags", "Shop maintenance"],
        "Other": ["Mobile recharge", "Medicine", "Miscellaneous"],
    }
    ranges = {"Food": (40, 300), "Travel": (20, 500), "Shopping": (200, 1500),
              "Education": (50, 2000), "Electricity": (800, 2500), "Rent": (3000, 6000),
              "Stock/Purchase": (1000, 8000), "Staff Salary": (3000, 6000),
              "Supplier Payment": (1500, 7000), "Business Expense": (100, 1200),
              "Other": (50, 600)}
    payments = ["Cash", "UPI", "Card", "Bank Transfer"]
    today = date.today()
    for _ in range(110):
        cat = rnd.choice(list(samples))
        if cat in ("Rent", "Electricity", "Staff Salary") and rnd.random() < 0.6:
            cat = rnd.choice(["Food", "Travel", "Food", "Education"])
        lo, hi = ranges[cat]
        day = today - timedelta(days=rnd.randint(0, 150))
        add_expense(rnd.choice(samples[cat]), round(rnd.uniform(lo, hi), 2), cat,
                    day.isoformat(), rnd.choice(payments), "Demo entry")
    add_expense("Tea & snacks", 60, "Food", today.isoformat(), "Cash", "Demo entry (today)")
    for _ in range(45):
        day = today - timedelta(days=rnd.randint(0, 150))
        src = rnd.choice(["Daily Sales", "Daily Sales", "Pocket Money", "Part-time Job"])
        amt = rnd.uniform(1500, 9000) if src == "Daily Sales" else rnd.uniform(2000, 6000)
        add_income(src, round(amt, 2), day.isoformat(), "Demo entry")
    add_income("Daily Sales", 4500, today.isoformat(), "Demo entry (today)")
    set_setting("pocket_money", "8000")


# ---------------- backup ----------------
def backup_database(dest_path):
    shutil.copy2(DB_PATH, dest_path)
