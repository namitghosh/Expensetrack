"""main.py - Entry point. Run:  python main.py"""
import sqlite3
import tkinter as tk
from tkinter import messagebox
import database
from ui import *
from dashboard import DashboardPage
from expenses import AddExpensePage, HistoryPage
from income import IncomePage
from modes import StudentPage, BusinessPage
from reports import ReportsPage
from charts import ChartsPage
from export import DataPage

PAGES = [("dashboard", "\U0001F3E0  Dashboard", DashboardPage),
         ("add_expense", "\u2795  Add Expense", AddExpensePage),
         ("history", "\U0001F4CB  Expense History", HistoryPage),
         ("income", "\U0001F4B0  Income", IncomePage),
         ("student", "\U0001F393  Student Mode", StudentPage),
         ("business", "\U0001F3EA  Business Mode", BusinessPage),
         ("reports", "\U0001F4C4  Reports", ReportsPage),
         ("charts", "\U0001F4CA  Charts", ChartsPage),
         ("data", "\U0001F4BE  Data / Backup", DataPage)]


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Expense Calculator - Expense Management System for Students and Small Businesses")
        self.geometry("1180x720")
        self.minsize(1000, 620)
        setup_style(self)
        try:
            database.init_db()
        except sqlite3.Error as err:
            messagebox.showerror("Database error", f"Could not open database:\n{err}")
            self.destroy()
            raise SystemExit(1)
        side = tk.Frame(self, bg=DARK, width=220)
        side.pack(side="left", fill="y")
        side.pack_propagate(False)
        tk.Label(side, text="Expense\nCalculator", bg=DARK, fg=WHITE, font=("Segoe UI", 17, "bold"),
                 pady=20).pack()
        self.container = tk.Frame(self, bg=GREY)
        self.container.pack(side="right", fill="both", expand=True)
        self.pages, self.nav = {}, {}
        for key, label, cls in PAGES:
            page = cls(self.container, self)
            page.place(relx=0, rely=0, relwidth=1, relheight=1)
            self.pages[key] = page
            self.nav[key] = tk.Button(side, text=label, anchor="w", bg=DARK, fg=WHITE, relief="flat",
                                      font=("Segoe UI", 11), padx=20, pady=9, cursor="hand2",
                                      activebackground=BLUE, activeforeground=WHITE,
                                      command=lambda k=key: self.show(k))
            self.nav[key].pack(fill="x")
        self.show("dashboard")

    def show(self, key, data=None):
        for k, b in self.nav.items():
            b.config(bg=BLUE if k == key else DARK)
        self.pages[key].refresh(data)
        self.pages[key].tkraise()


if __name__ == "__main__":
    App().mainloop()
