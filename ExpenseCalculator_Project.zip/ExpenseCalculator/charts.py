"""charts.py - Simple charts drawn on a Tkinter Canvas (no extra libraries needed)."""
import tkinter as tk
import database
from ui import *

PALETTE = [BLUE, "#5B9BE8", ORANGE, GREEN, RED, "#8B5CF6", "#0EA5A4", "#9CA3AF"]


def _no_data(canvas, w, h):
    canvas.create_text(w / 2, h / 2, text="No data to display", font=("Segoe UI", 12), fill="#6B7280")


def draw_hbars(canvas, items, title):
    """Horizontal bar chart. items = [(label, value)]."""
    canvas.delete("all")
    w, h = canvas.winfo_width(), canvas.winfo_height()
    canvas.create_text(20, 20, text=title, anchor="w", font=("Segoe UI", 13, "bold"), fill=DARK)
    if not items:
        return _no_data(canvas, w, h)
    top, left, right = 50, 150, 110
    step = min(40, (h - top - 20) / len(items))
    maxv = max(v for _, v in items) or 1
    for i, (label, val) in enumerate(items):
        y = top + i * step
        length = (w - left - right) * val / maxv
        canvas.create_text(left - 8, y + step * 0.4, text=label, anchor="e", font=FONT, fill=TEXT)
        canvas.create_rectangle(left, y + 4, left + length, y + step - 6, fill=PALETTE[i % len(PALETTE)], width=0)
        canvas.create_text(left + length + 6, y + step * 0.4, text=money(val), anchor="w", font=FONT, fill=TEXT)


def draw_vbars(canvas, labels, series, title):
    """Grouped vertical bars. series = [(name, values, colour)]."""
    canvas.delete("all")
    w, h = canvas.winfo_width(), canvas.winfo_height()
    canvas.create_text(20, 20, text=title, anchor="w", font=("Segoe UI", 13, "bold"), fill=DARK)
    maxv = max([max(v) for _, v, _ in series] + [0])
    if maxv <= 0:
        return _no_data(canvas, w, h)
    left, right, top, bottom = 80, 20, 60, 40
    plot_h, plot_w = h - top - bottom, w - left - right
    for i in range(5):
        y = top + plot_h * i / 4
        canvas.create_line(left, y, w - right, y, fill="#E5E7EB")
        canvas.create_text(left - 6, y, text=f"{maxv * (4 - i) / 4:,.0f}", anchor="e", font=("Segoe UI", 8), fill="#6B7280")
    group = plot_w / len(labels)
    bar_w = group * 0.7 / len(series)
    for i, label in enumerate(labels):
        for j, (_, vals, color) in enumerate(series):
            x0 = left + i * group + group * 0.15 + j * bar_w
            y0 = top + plot_h * (1 - vals[i] / maxv)
            canvas.create_rectangle(x0, y0, x0 + bar_w - 2, top + plot_h, fill=color, width=0)
        canvas.create_text(left + i * group + group / 2, h - bottom + 14, text=label, font=FONT, fill=TEXT)
    for j, (name, _, color) in enumerate(series):
        canvas.create_rectangle(w - 190 + j * 95, 12, w - 178 + j * 95, 24, fill=color, width=0)
        canvas.create_text(w - 174 + j * 95, 18, text=name, anchor="w", font=FONT, fill=TEXT)


class ChartsPage(Page):
    def __init__(self, parent, app):
        super().__init__(parent, app)
        heading(self, "Charts")
        bar = tk.Frame(self, bg=GREY)
        bar.pack(fill="x", padx=25)
        self.current = "category"
        for key, text in (("category", "Expenses by Category"), ("monthly", "Monthly Expenses"),
                          ("compare", "Income vs Expenses")):
            button(bar, text, lambda k=key: self.show_chart(k)).pack(side="left", padx=(0, 8))
        self.canvas = tk.Canvas(self, bg=WHITE, highlightthickness=0)
        self.canvas.pack(fill="both", expand=True, padx=25, pady=12)
        self.canvas.bind("<Configure>", lambda e: self.draw())

    def refresh(self, data=None):
        self.after(50, self.draw)

    def show_chart(self, key):
        self.current = key
        self.draw()

    def draw(self):
        if self.current == "category":
            draw_hbars(self.canvas, database.category_totals(), "Expenses by Category")
        else:
            months = database.last_months(6)
            exp = database.month_totals("expenses", months)
            if self.current == "monthly":
                draw_vbars(self.canvas, months, [("Expenses", exp, BLUE)], "Monthly Expenses (Last 6 Months)")
            else:
                inc = database.month_totals("income", months)
                draw_vbars(self.canvas, months, [("Income", inc, GREEN), ("Expenses", exp, RED)],
                           "Income vs Expenses (Last 6 Months)")
