"""expenses.py - Add/Edit expense form and Expense History screen."""
import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import date
import database
from ui import *


class AddExpensePage(Page):
    def __init__(self, parent, app):
        super().__init__(parent, app)
        self.edit_id = None
        self.title_lbl = tk.Label(self, font=("Segoe UI", 18, "bold"), bg=GREY, fg=DARK)
        self.title_lbl.pack(anchor="w", padx=25, pady=(18, 6))
        form = tk.Frame(self, bg=WHITE, padx=25, pady=20)
        form.pack(anchor="nw", padx=25, pady=10)
        self.v = {k: tk.StringVar() for k in ("name", "amount", "category", "date", "payment")}
        tk.Label(form, text="Expense Name *", bg=WHITE, font=FONT).grid(row=0, column=0, sticky="w", pady=6)
        ttk.Entry(form, textvariable=self.v["name"], width=35).grid(row=0, column=1, pady=6, padx=10)
        tk.Label(form, text="Amount (\u20b9) *", bg=WHITE, font=FONT).grid(row=1, column=0, sticky="w", pady=6)
        ttk.Entry(form, textvariable=self.v["amount"], width=35).grid(row=1, column=1, pady=6, padx=10)
        tk.Label(form, text="Category *", bg=WHITE, font=FONT).grid(row=2, column=0, sticky="w", pady=6)
        ttk.Combobox(form, textvariable=self.v["category"], values=CATEGORIES, width=32,
                     state="readonly").grid(row=2, column=1, pady=6, padx=10)
        tk.Label(form, text="Date (YYYY-MM-DD) *", bg=WHITE, font=FONT).grid(row=3, column=0, sticky="w", pady=6)
        ttk.Entry(form, textvariable=self.v["date"], width=35).grid(row=3, column=1, pady=6, padx=10)
        tk.Label(form, text="Payment Method", bg=WHITE, font=FONT).grid(row=4, column=0, sticky="w", pady=6)
        ttk.Combobox(form, textvariable=self.v["payment"], values=PAYMENTS, width=32,
                     state="readonly").grid(row=4, column=1, pady=6, padx=10)
        tk.Label(form, text="Description", bg=WHITE, font=FONT).grid(row=5, column=0, sticky="nw", pady=6)
        self.desc = tk.Text(form, width=35, height=4, font=FONT, relief="solid", bd=1)
        self.desc.grid(row=5, column=1, pady=6, padx=10)
        btns = tk.Frame(form, bg=WHITE)
        btns.grid(row=6, column=1, sticky="w", padx=10, pady=(12, 0))
        button(btns, "Save Expense", self.save, "success").pack(side="left", padx=(0, 8))
        button(btns, "Clear", lambda: self.refresh(), "light").pack(side="left")

    def refresh(self, data=None):
        data = dict(data) if data else {}
        self.edit_id = data.get("id")
        self.title_lbl.config(text="Edit Expense" if self.edit_id else "Add Expense")
        self.v["name"].set(data.get("name", ""))
        self.v["amount"].set(str(data["amount"]) if "amount" in data else "")
        self.v["category"].set(data.get("category", "Food"))
        self.v["date"].set(data.get("date", date.today().isoformat()))
        self.v["payment"].set(data.get("payment", "Cash"))
        self.desc.delete("1.0", "end")
        self.desc.insert("1.0", data.get("description", "") or "")

    def save(self):
        name = self.v["name"].get().strip()
        if not name:
            return messagebox.showerror("Error", "Expense name is required.")
        try:
            amount = parse_amount(self.v["amount"].get())
            day = parse_date(self.v["date"].get())
        except ValueError as err:
            return messagebox.showerror("Invalid input", str(err))
        if not self.v["category"].get():
            return messagebox.showerror("Error", "Please select a category.")
        args = (name, amount, self.v["category"].get(), day, self.v["payment"].get(),
                self.desc.get("1.0", "end").strip())
        try:
            if self.edit_id:
                database.update_expense(self.edit_id, *args)
            else:
                database.add_expense(*args)
        except sqlite3.Error as err:
            return messagebox.showerror("Database error", str(err))
        messagebox.showinfo("Success", "Expense saved successfully.")
        went_edit = self.edit_id
        self.refresh()
        if went_edit:
            self.app.show("history")


class HistoryPage(Page):
    def __init__(self, parent, app):
        super().__init__(parent, app)
        heading(self, "Expense History")
        bar = tk.Frame(self, bg=GREY)
        bar.pack(fill="x", padx=25)
        self.search, self.cat = tk.StringVar(), tk.StringVar(value="All")
        self.d_from, self.d_to = tk.StringVar(), tk.StringVar()
        tk.Label(bar, text="Search:", bg=GREY, font=FONT).pack(side="left")
        ttk.Entry(bar, textvariable=self.search, width=18).pack(side="left", padx=(4, 10))
        tk.Label(bar, text="Category:", bg=GREY, font=FONT).pack(side="left")
        ttk.Combobox(bar, textvariable=self.cat, values=["All"] + CATEGORIES, width=15,
                     state="readonly").pack(side="left", padx=(4, 10))
        tk.Label(bar, text="From:", bg=GREY, font=FONT).pack(side="left")
        ttk.Entry(bar, textvariable=self.d_from, width=11).pack(side="left", padx=(4, 6))
        tk.Label(bar, text="To:", bg=GREY, font=FONT).pack(side="left")
        ttk.Entry(bar, textvariable=self.d_to, width=11).pack(side="left", padx=(4, 10))
        button(bar, "Apply", self.load).pack(side="left", padx=3)
        button(bar, "Reset", self.reset, "light").pack(side="left")
        self.tree = make_table(self, ("ID", "Date", "Name", "Category", "Amount", "Payment", "Description"),
                               (45, 95, 200, 130, 110, 100, 220))
        foot = tk.Frame(self, bg=GREY)
        foot.pack(fill="x", padx=25, pady=(0, 12))
        button(foot, "Edit Selected", self.edit).pack(side="left", padx=(0, 8))
        button(foot, "Delete Selected", self.delete, "danger").pack(side="left")
        self.total_lbl = tk.Label(foot, font=("Segoe UI", 12, "bold"), bg=GREY, fg=DARK)
        self.total_lbl.pack(side="right")

    def reset(self):
        self.search.set(""); self.cat.set("All"); self.d_from.set(""); self.d_to.set("")
        self.load()

    def refresh(self, data=None):
        self.load()

    def load(self):
        try:
            f = parse_date(self.d_from.get()) if self.d_from.get().strip() else ""
            t = parse_date(self.d_to.get()) if self.d_to.get().strip() else ""
            rows = database.get_expenses(self.search.get().strip(), self.cat.get(), f, t)
        except ValueError as err:
            return messagebox.showerror("Invalid date", str(err))
        except sqlite3.Error as err:
            return messagebox.showerror("Database error", str(err))
        fill_table(self.tree, [(r["id"], (r["id"], r["date"], r["name"], r["category"],
                                          money(r["amount"]), r["payment"], r["description"])) for r in rows])
        self.total_lbl.config(text=f"Filtered Total: {money(sum(r['amount'] for r in rows))}   ({len(rows)} records)")

    def edit(self):
        exp_id = selected_id(self.tree)
        if exp_id is None:
            return messagebox.showwarning("Select a record", "Please select an expense to edit.")
        self.app.show("add_expense", database.get_expense(exp_id))

    def delete(self):
        exp_id = selected_id(self.tree)
        if exp_id is None:
            return messagebox.showwarning("Select a record", "Please select an expense to delete.")
        if messagebox.askyesno("Confirm delete", "Delete this expense permanently?"):
            try:
                database.delete_expense(exp_id)
            except sqlite3.Error as err:
                return messagebox.showerror("Database error", str(err))
            self.load()
            messagebox.showinfo("Deleted", "Expense deleted.")
