"""ui.py - Shared colours, styles and small helper functions for the GUI."""
import tkinter as tk
from tkinter import ttk
from datetime import datetime

BLUE, DARK, LIGHT_BLUE = "#1E63C6", "#0F3D7A", "#CFE0FA"
GREY, WHITE, TEXT = "#F2F4F7", "#FFFFFF", "#1F2937"
GREEN, RED, ORANGE = "#1E8E5A", "#D64545", "#E08A1E"

CATEGORIES = ["Food", "Travel", "Shopping", "Education", "Electricity", "Rent",
              "Stock/Purchase", "Staff Salary", "Supplier Payment",
              "Business Expense", "Other"]
PAYMENTS = ["Cash", "UPI", "Card", "Bank Transfer", "Other"]
FONT = ("Segoe UI", 10)


def money(value):
    return f"\u20b9{value:,.2f}"


def parse_amount(text):
    """Convert text to a positive number or raise ValueError with a clear message."""
    try:
        value = float(text.strip().replace(",", ""))
    except ValueError:
        raise ValueError("Amount must be a number, e.g. 250 or 99.50")
    if value <= 0:
        raise ValueError("Amount must be greater than 0")
    return round(value, 2)


def parse_date(text):
    """Validate a YYYY-MM-DD date string."""
    try:
        return datetime.strptime(text.strip(), "%Y-%m-%d").strftime("%Y-%m-%d")
    except ValueError:
        raise ValueError("Date must be in YYYY-MM-DD format, e.g. 2025-01-31")


def setup_style(root):
    s = ttk.Style(root)
    s.theme_use("clam")
    s.configure("Treeview", background=WHITE, fieldbackground=WHITE, foreground=TEXT,
                rowheight=26, font=FONT)
    s.configure("Treeview.Heading", background=BLUE, foreground=WHITE,
                font=("Segoe UI", 10, "bold"))
    s.map("Treeview", background=[("selected", LIGHT_BLUE)], foreground=[("selected", TEXT)])
    s.map("Treeview.Heading", background=[("active", DARK)])


class Page(tk.Frame):
    """Base class for every screen. refresh() reloads data from the database."""
    def __init__(self, parent, app):
        super().__init__(parent, bg=GREY)
        self.app = app

    def refresh(self, data=None):
        pass


def heading(parent, text):
    tk.Label(parent, text=text, font=("Segoe UI", 18, "bold"), bg=GREY,
             fg=DARK).pack(anchor="w", padx=25, pady=(18, 6))


def button(parent, text, command, kind="primary"):
    colors = {"primary": (BLUE, WHITE), "danger": (RED, WHITE),
              "success": (GREEN, WHITE), "light": ("#E5E7EB", TEXT)}
    bg, fg = colors[kind]
    return tk.Button(parent, text=text, command=command, bg=bg, fg=fg, relief="flat",
                     font=("Segoe UI", 10, "bold"), padx=14, pady=6, cursor="hand2",
                     activebackground=DARK, activeforeground=WHITE)


def make_table(parent, columns, widths):
    """Create a Treeview with a scrollbar. Returns the tree."""
    frame = tk.Frame(parent, bg=GREY)
    frame.pack(fill="both", expand=True, padx=25, pady=6)
    tree = ttk.Treeview(frame, columns=columns, show="headings", selectmode="browse")
    for col, w in zip(columns, widths):
        tree.heading(col, text=col)
        tree.column(col, width=w, anchor="e" if col == "Amount" else "w")
    bar = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
    tree.configure(yscrollcommand=bar.set)
    tree.pack(side="left", fill="both", expand=True)
    bar.pack(side="right", fill="y")
    return tree


def fill_table(tree, rows):
    """rows = list of (iid, values)."""
    tree.delete(*tree.get_children())
    for iid, values in rows:
        tree.insert("", "end", iid=str(iid), values=values)


def selected_id(tree):
    sel = tree.selection()
    return int(sel[0]) if sel else None


def cards_row(parent, specs, per_row=3):
    """Create dashboard cards. specs = [(key, title, colour)]. Returns {key: label}."""
    holder = tk.Frame(parent, bg=GREY)
    holder.pack(fill="x", padx=20, pady=5)
    labels = {}
    for i, (key, title, color) in enumerate(specs):
        card = tk.Frame(holder, bg=WHITE, highlightbackground="#D9DEE5", highlightthickness=1)
        card.grid(row=i // per_row, column=i % per_row, padx=6, pady=6, sticky="nsew")
        holder.grid_columnconfigure(i % per_row, weight=1)
        tk.Frame(card, bg=color, height=4).pack(fill="x")
        tk.Label(card, text=title, bg=WHITE, fg="#6B7280", font=FONT).pack(anchor="w", padx=14, pady=(10, 0))
        labels[key] = tk.Label(card, text="-", bg=WHITE, fg=color, font=("Segoe UI", 17, "bold"))
        labels[key].pack(anchor="w", padx=14, pady=(2, 12))
    return labels
