"""modes.py - Student Mode and Small Business Mode screens."""
import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import date
import database
from ui import *


def month_range():
    today = date.today()
    return today.replace(day=1).isoformat(), today.isoformat()


class StudentPage(Page):
    def __init__(self, parent, app):
        super().__init__(parent, app)
        heading(self, "Student Mode")
        bar = tk.Frame(self, bg=GREY)
        bar.pack(fill="x", padx=25)
        tk.Label(bar, text="Monthly pocket money (\u20b9):", bg=GREY, font=FONT).pack(side="left")
        self.pocket = tk.StringVar()
        ttk.Entry(bar, textvariable=self.pocket, width=12).pack(side="left", padx=6)
        button(bar, "Save", self.save_pocket).pack(side="left")
        self.cards = cards_row(self, [
            ("pocket", "Pocket Money", BLUE), ("spent", "Spent This Month", RED),
            ("left", "Remaining", GREEN), ("food", "Food Expenses", ORANGE),
            ("travel", "Travel Expenses", BLUE), ("college", "College Expenses", DARK)])
        q = tk.Frame(self, bg=GREY)
        q.pack(fill="x", padx=25, pady=4)
        for cat in ("Food", "Travel", "Education"):
            button(q, f"+ Add {cat}", lambda c=cat: app.show("add_expense", {"category": c}),
                   "light").pack(side="left", padx=(0, 8))
        tk.Label(self, text="Monthly Spending Summary", font=("Segoe UI", 12, "bold"),
                 bg=GREY, fg=DARK).pack(anchor="w", padx=25, pady=(8, 0))
        self.tree = make_table(self, ("Month", "Amount"), (200, 160))

    def save_pocket(self):
        try:
            database.set_setting("pocket_money", parse_amount(self.pocket.get()))
        except ValueError as err:
            return messagebox.showerror("Invalid input", str(err))
        except sqlite3.Error as err:
            return messagebox.showerror("Database error", str(err))
        messagebox.showinfo("Success", "Pocket money saved.")
        self.refresh()

    def refresh(self, data=None):
        f, t = month_range()
        pocket = float(database.get_setting("pocket_money", 0))
        spent = database.sum_expenses(f, t)
        self.pocket.set(str(pocket))
        self.cards["pocket"].config(text=money(pocket))
        self.cards["spent"].config(text=money(spent))
        self.cards["left"].config(text=money(pocket - spent), fg=GREEN if pocket >= spent else RED)
        self.cards["food"].config(text=money(database.sum_expenses(f, t, "Food")))
        self.cards["travel"].config(text=money(database.sum_expenses(f, t, "Travel")))
        self.cards["college"].config(text=money(database.sum_expenses(f, t, "Education")))
        months = database.last_months(6)[::-1]
        totals = database.month_totals("expenses", months[::-1])[::-1]
        fill_table(self.tree, [(m, (m, money(a))) for m, a in zip(months, totals)])


class BusinessPage(Page):
    BUSINESS_CATS = ["Stock/Purchase", "Electricity", "Rent", "Staff Salary",
                     "Supplier Payment", "Business Expense", "Other"]

    def __init__(self, parent, app):
        super().__init__(parent, app)
        heading(self, "Small Business Mode")
        self.cards = cards_row(self, [
            ("t_sales", "Today's Sales", GREEN), ("t_exp", "Today's Expenses", ORANGE),
            ("m_inc", "Month Income", GREEN), ("m_exp", "Month Expenses", RED),
            ("profit", "Month Profit / Loss", BLUE), ("all", "Overall Profit / Loss", DARK)])
        q = tk.Frame(self, bg=GREY)
        q.pack(fill="x", padx=25, pady=4)
        button(q, "+ Daily Sales", lambda: app.show("income", {"source": "Daily Sales"}), "success").pack(side="left", padx=(0, 6))
        for text, cat in (("Stock/Purchase", "Stock/Purchase"), ("Electricity/Rent", "Electricity"),
                          ("Staff Salary", "Staff Salary"), ("Supplier Payment", "Supplier Payment")):
            button(q, "+ " + text, lambda c=cat: app.show("add_expense", {"category": c}),
                   "light").pack(side="left", padx=(0, 6))
        tk.Label(self, text="This Month's Business Expenses by Category", font=("Segoe UI", 12, "bold"),
                 bg=GREY, fg=DARK).pack(anchor="w", padx=25, pady=(8, 0))
        self.tree = make_table(self, ("Category", "Amount"), (250, 160))

    def refresh(self, data=None):
        f, t = month_range()
        today = date.today().isoformat()
        m_inc, m_exp = database.sum_income(f, t), database.sum_expenses(f, t)
        self.cards["t_sales"].config(text=money(database.sum_income(today, today)))
        self.cards["t_exp"].config(text=money(database.sum_expenses(today, today)))
        self.cards["m_inc"].config(text=money(m_inc))
        self.cards["m_exp"].config(text=money(m_exp))
        for key, val in (("profit", m_inc - m_exp), ("all", database.sum_income() - database.sum_expenses())):
            self.cards[key].config(text=money(val), fg=GREEN if val >= 0 else RED)
        fill_table(self.tree, [(c, (c, money(database.sum_expenses(f, t, c)))) for c in self.BUSINESS_CATS])
