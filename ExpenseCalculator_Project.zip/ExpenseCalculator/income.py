"""income.py - Income management screen."""
import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import date
import database
from ui import *


class IncomePage(Page):
    def __init__(self, parent, app):
        super().__init__(parent, app)
        heading(self, "Income Management")
        form = tk.Frame(self, bg=WHITE, padx=20, pady=14)
        form.pack(fill="x", padx=25, pady=6)
        self.v = {k: tk.StringVar() for k in ("source", "amount", "date", "desc")}
        fields = [("Income Source *", "source", 18), ("Amount (\u20b9) *", "amount", 12),
                  ("Date *", "date", 12), ("Description", "desc", 24)]
        for i, (label, key, w) in enumerate(fields):
            tk.Label(form, text=label, bg=WHITE, font=FONT).grid(row=0, column=i, sticky="w", padx=6)
            ttk.Entry(form, textvariable=self.v[key], width=w).grid(row=1, column=i, padx=6, pady=4)
        button(form, "Save Income", self.save, "success").grid(row=1, column=4, padx=10)
        self.tree = make_table(self, ("ID", "Date", "Source", "Amount", "Description"), (45, 100, 180, 120, 300))
        foot = tk.Frame(self, bg=GREY)
        foot.pack(fill="x", padx=25, pady=(0, 12))
        button(foot, "Delete Selected", self.delete, "danger").pack(side="left")
        self.sum_lbl = tk.Label(foot, font=("Segoe UI", 11, "bold"), bg=GREY, fg=DARK)
        self.sum_lbl.pack(side="right")

    def refresh(self, data=None):
        data = data or {}
        self.v["source"].set(data.get("source", ""))
        self.v["amount"].set("")
        self.v["date"].set(date.today().isoformat())
        self.v["desc"].set("")
        self.load()

    def load(self):
        rows = database.get_income()
        fill_table(self.tree, [(r["id"], (r["id"], r["date"], r["source"], money(r["amount"]),
                                          r["description"])) for r in rows])
        inc, exp = database.sum_income(), database.sum_expenses()
        self.sum_lbl.config(text=f"Income: {money(inc)}   |   Expenses: {money(exp)}   |   Net: {money(inc - exp)}")

    def save(self):
        source = self.v["source"].get().strip()
        if not source:
            return messagebox.showerror("Error", "Income source is required.")
        try:
            amount = parse_amount(self.v["amount"].get())
            day = parse_date(self.v["date"].get())
            database.add_income(source, amount, day, self.v["desc"].get().strip())
        except ValueError as err:
            return messagebox.showerror("Invalid input", str(err))
        except sqlite3.Error as err:
            return messagebox.showerror("Database error", str(err))
        messagebox.showinfo("Success", "Income saved successfully.")
        self.refresh()

    def delete(self):
        inc_id = selected_id(self.tree)
        if inc_id is None:
            return messagebox.showwarning("Select a record", "Please select an income record.")
        if messagebox.askyesno("Confirm delete", "Delete this income record permanently?"):
            try:
                database.delete_income(inc_id)
            except sqlite3.Error as err:
                return messagebox.showerror("Database error", str(err))
            self.load()
            messagebox.showinfo("Deleted", "Income record deleted.")
