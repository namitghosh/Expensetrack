"""dashboard.py - Home screen with summary cards and quick actions."""
import tkinter as tk
from datetime import date
import database
from ui import *


class DashboardPage(Page):
    def __init__(self, parent, app):
        super().__init__(parent, app)
        heading(self, "Dashboard")
        self.cards = cards_row(self, [
            ("total", "Total Expenses", RED), ("today", "Today's Expenses", ORANGE),
            ("month", "Monthly Expenses", BLUE), ("count", "Transactions", DARK),
            ("income", "Total Income", GREEN), ("balance", "Balance / Profit", GREEN)])
        bar = tk.Frame(self, bg=GREY)
        bar.pack(fill="x", padx=25, pady=8)
        button(bar, "+ Add Expense", lambda: app.show("add_expense")).pack(side="left", padx=(0, 8))
        button(bar, "+ Add Income", lambda: app.show("income"), "success").pack(side="left")
        tk.Label(self, text="Recent Transactions", font=("Segoe UI", 12, "bold"),
                 bg=GREY, fg=DARK).pack(anchor="w", padx=25, pady=(8, 0))
        self.tree = make_table(self, ("Date", "Type", "Title", "Amount"), (110, 90, 300, 130))

    def refresh(self, data=None):
        today = date.today()
        month_start = today.replace(day=1).isoformat()
        total_exp, total_inc = database.sum_expenses(), database.sum_income()
        self.cards["total"].config(text=money(total_exp))
        self.cards["today"].config(text=money(database.sum_expenses(today.isoformat(), today.isoformat())))
        self.cards["month"].config(text=money(database.sum_expenses(month_start, today.isoformat())))
        self.cards["count"].config(text=str(database.count_transactions()))
        self.cards["income"].config(text=money(total_inc))
        bal = total_inc - total_exp
        self.cards["balance"].config(text=money(bal), fg=GREEN if bal >= 0 else RED)
        rows = [(r["date"], "Expense", r["name"], money(r["amount"]), r["id"], "e") for r in database.get_expenses()[:8]]
        rows += [(r["date"], "Income", r["source"], money(r["amount"]), r["id"], "i") for r in database.get_income()[:8]]
        rows.sort(key=lambda r: r[0], reverse=True)
        fill_table(self.tree, [(f"{r[5]}{r[4]}", r[:4]) for r in rows[:10]])
