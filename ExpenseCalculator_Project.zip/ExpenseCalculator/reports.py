"""reports.py - Report generation (plain text) and the Reports screen."""
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import date, timedelta, datetime
import database
from ui import *

LINE = "=" * 64


def daily_report(day):
    rows = database.get_expenses(date_from=day, date_to=day)
    out = [f"DAILY EXPENSE REPORT - {day}", LINE]
    for r in rows:
        out.append(f"{r['name'][:26]:<26}{r['category'][:18]:<18}{money(r['amount']):>18}")
    if not rows:
        out.append("No expenses recorded for this day.")
    out += [LINE, f"Total: {money(sum(r['amount'] for r in rows))}   ({len(rows)} entries)"]
    return "\n".join(out)


def weekly_report():
    today = date.today()
    start = today - timedelta(days=6)
    data = database.expense_by_day(start.isoformat(), today.isoformat())
    out = [f"WEEKLY EXPENSE REPORT - {start} to {today}", LINE]
    for i in range(7):
        d = (start + timedelta(days=i)).isoformat()
        out.append(f"{d}  {datetime.strptime(d, '%Y-%m-%d').strftime('%A'):<12}{money(data.get(d, 0)):>20}")
    out += [LINE, f"Weekly Total: {money(sum(data.values()))}"]
    return "\n".join(out)


def monthly_report(month):
    f, t = f"{month}-01", f"{month}-31"
    data = database.expense_by_day(f, t)
    out = [f"MONTHLY EXPENSE REPORT - {month}", LINE]
    for d, amt in data.items():
        out.append(f"{d}{money(amt):>30}")
    if not data:
        out.append("No expenses recorded for this month.")
    out += [LINE, f"Monthly Total: {money(sum(data.values()))}", "", "By category:"]
    for cat, amt in database.category_totals(f, t):
        out.append(f"  {cat:<22}{money(amt):>20}")
    return "\n".join(out)


def category_report():
    rows = database.category_totals()
    total = sum(a for _, a in rows) or 1
    out = ["CATEGORY-WISE EXPENSE REPORT (All Time)", LINE]
    for cat, amt in rows:
        out.append(f"{cat:<24}{money(amt):>18}{amt / total * 100:>9.1f}%")
    out += [LINE, f"Grand Total: {money(sum(a for _, a in rows))}"]
    return "\n".join(out)


def income_vs_expense_report():
    months = database.last_months(6)
    inc, exp = database.month_totals("income", months), database.month_totals("expenses", months)
    out = ["INCOME VS EXPENSE REPORT (Last 6 Months)", LINE,
           f"{'Month':<10}{'Income':>16}{'Expense':>16}{'Net':>18}"]
    for m, i, e in zip(months, inc, exp):
        out.append(f"{m:<10}{money(i):>16}{money(e):>16}{money(i - e):>18}")
    out += [LINE, f"{'TOTAL':<10}{money(sum(inc)):>16}{money(sum(exp)):>16}{money(sum(inc) - sum(exp)):>18}"]
    return "\n".join(out)


def profit_loss_report():
    today = date.today()
    out = ["BUSINESS PROFIT / LOSS SUMMARY", LINE]
    for label, f, t in (("This Month", today.replace(day=1).isoformat(), today.isoformat()),
                        ("All Time", None, None)):
        inc, exp = database.sum_income(f, t), database.sum_expenses(f, t)
        net = inc - exp
        out += [f"{label}", f"  Total Income   : {money(inc)}", f"  Total Expenses : {money(exp)}",
                f"  Net            : {money(abs(net))}  ({'PROFIT' if net >= 0 else 'LOSS'})", ""]
    return "\n".join(out)


class ReportsPage(Page):
    TYPES = ["Daily Expense Report", "Weekly Expense Report", "Monthly Expense Report",
             "Category-wise Report", "Income vs Expense Report", "Profit/Loss Summary"]

    def __init__(self, parent, app):
        super().__init__(parent, app)
        heading(self, "Reports")
        bar = tk.Frame(self, bg=GREY)
        bar.pack(fill="x", padx=25)
        self.kind, self.value = tk.StringVar(value=self.TYPES[0]), tk.StringVar()
        ttk.Combobox(bar, textvariable=self.kind, values=self.TYPES, width=28,
                     state="readonly").pack(side="left")
        tk.Label(bar, text="  Date (YYYY-MM-DD) or Month (YYYY-MM):", bg=GREY, font=FONT).pack(side="left")
        ttk.Entry(bar, textvariable=self.value, width=13).pack(side="left", padx=6)
        button(bar, "Generate", self.generate).pack(side="left")
        self.text = tk.Text(self, font=("Consolas", 10), bg=WHITE, relief="flat", padx=15, pady=12)
        self.text.pack(fill="both", expand=True, padx=25, pady=12)

    def refresh(self, data=None):
        self.value.set(date.today().isoformat())
        self.generate()

    def generate(self):
        kind, val = self.kind.get(), self.value.get().strip()
        try:
            if kind == self.TYPES[0]:
                report = daily_report(parse_date(val))
            elif kind == self.TYPES[1]:
                report = weekly_report()
            elif kind == self.TYPES[2]:
                month = val[:7]
                datetime.strptime(month, "%Y-%m")
                report = monthly_report(month)
            elif kind == self.TYPES[3]:
                report = category_report()
            elif kind == self.TYPES[4]:
                report = income_vs_expense_report()
            else:
                report = profit_loss_report()
        except ValueError:
            return messagebox.showerror("Invalid input", "Enter a valid date (YYYY-MM-DD) or month (YYYY-MM).")
        self.text.config(state="normal")
        self.text.delete("1.0", "end")
        self.text.insert("1.0", report)
        self.text.config(state="disabled")
