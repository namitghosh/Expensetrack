# Expense Calculator – Expense Management System for Students and Small Businesses

## Introduction
Expense Calculator is an offline desktop application (Python + Tkinter + SQLite) that helps
**college/hostel students** and **small businesses** (kirana stores, small retail shops,
home-based businesses) record, calculate and analyse daily expenses and income.

## Features
- **Dashboard** – total / today's / monthly expenses, transactions count, total income, balance/profit, quick-add buttons, recent transactions
- **Add Expense** – name, amount, category, date, payment method, description
- **Expense History** – table, search, category and date filters, edit, delete (with confirmation), filtered total
- **Student Mode** – pocket money tracking, food/travel/college expenses, monthly spending summary
- **Small Business Mode** – daily sales, stock/purchase, electricity/rent, staff salary, supplier payments, profit/loss
- **Income Management** – source, amount, date, description; total income, total expenses, net balance
- **Reports** – daily, weekly, monthly, category-wise, income vs expense, profit/loss summary
- **Charts** – expenses by category, monthly expenses, income vs expenses (drawn with Tkinter Canvas)
- **Data Management** – CSV export (expenses & income), database backup
- Input validation, success/error messages, database error handling, demo data included

## Technologies Used
Python 3, Tkinter (GUI), SQLite3 (database), csv/shutil (export & backup). No paid APIs, works fully offline.

## Project Structure
```text
ExpenseCalculator/
├── main.py         # entry point, sidebar navigation
├── database.py     # all SQLite operations + demo data
├── ui.py           # colours, styles, shared widgets, validation helpers
├── dashboard.py    # dashboard screen
├── expenses.py     # add/edit expense + expense history
├── income.py       # income management
├── modes.py        # student mode + small business mode
├── reports.py      # report generation
├── charts.py       # charts
├── export.py       # CSV export + backup
├── requirements.txt
├── README.md
├── database/expense_calculator.db   # SQLite DB with demo data
├── assets/icons/
└── screenshots/
```

## Installation
1. Install **Python 3.8 or newer** (https://www.python.org). Tkinter is included with the Windows/macOS installers.
   On Linux: `sudo apt install python3-tk`
2. Extract `ExpenseCalculator_Project.zip`.
3. Install dependencies: `pip install -r requirements.txt` (nothing extra is needed – standard library only).

## How to Run
```bash
cd ExpenseCalculator
python main.py
```

## How to Use
1. **Dashboard** shows the overall picture; use the quick buttons to add expense/income.
2. **Add Expense** – fill the form (fields marked * are required) and click *Save Expense*.
3. **Expense History** – search/filter, select a row, then *Edit* or *Delete*.
4. **Income** – record income; totals and net balance are shown at the bottom.
5. **Student Mode** – set monthly pocket money and view remaining balance and category spend.
6. **Business Mode** – add daily sales, stock, salary, supplier payments and see profit/loss.
7. **Reports / Charts** – choose a report or chart type. Dates use `YYYY-MM-DD`, months `YYYY-MM`.
8. **Data / Backup** – export CSV files or back up the database.

To start with fresh data, delete the demo records from Expense History / Income, or edit `seed_demo_data()` in `database.py` before the first run.

## Future Scope
Budget limits & alerts, recurring expenses, PDF reports, multi-user login, receipt image
attachments, Excel export, dark mode, mobile/web version.
